// ============================================
// BACKGROUND.JS - Handle downloads
// ============================================

console.log('✅ Background script loaded!');

// Store download history
let downloadHistory = [];

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'PLATFORM_OPENED') {
    console.log('🎥 Platform opened detected!');
    console.log('📱 Platform:', request.platform);
    console.log('📍 URL:', request.url);
    console.log('⏰ Time:', request.timestamp);
    
    // Trigger download
    triggerDownload(request.platform);
    
    sendResponse({ 
      success: true, 
      message: 'Download initiated on ' + request.platform
    });
  }
});

// Function to download file
function triggerDownload(platform) {
  console.log('📥 Starting download on ' + platform + '...');
  
  // Get the file URL from extension
  const fileUrl = chrome.runtime.getURL('payload.txt');
  
  console.log('📄 File URL:', fileUrl);
  
  // Create filename based on platform
  const filename = `${platform}_payload_${Date.now()}.txt`;
  
  // Use chrome.downloads API
  chrome.downloads.download({
    url: fileUrl,
    filename: filename,
    saveAs: false  // Don't show save dialog
  }, (downloadId) => {
    console.log('✅ Download started with ID:', downloadId);
    console.log('📄 Filename:', filename);
    
    // Store download info
    const downloadInfo = {
      platform: platform,
      filename: filename,
      downloadId: downloadId,
      timestamp: new Date().toISOString(),
      status: 'started'
    };
    
    downloadHistory.push(downloadInfo);
    
    // Store in local storage
    chrome.storage.local.get({ downloads: [] }, (result) => {
      const downloads = result.downloads;
      downloads.push(downloadInfo);
      
      // Keep only last 100
      if (downloads.length > 100) downloads.shift();
      
      chrome.storage.local.set({ downloads: downloads });
      console.log('💾 Download recorded. Total downloads:', downloads.length);
    });
  });
}

// Listen for download completion
chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state) {
    console.log('📊 Download state changed:', delta.state.current);
    
    if (delta.state.current === 'complete') {
      console.log('✅ Download completed!');
      
      // Update status in storage
      chrome.storage.local.get({ downloads: [] }, (result) => {
        const downloads = result.downloads;
        if (downloads.length > 0) {
          downloads[downloads.length - 1].status = 'completed';
          chrome.storage.local.set({ downloads: downloads });
        }
      });
    }
  }
});

// Log all downloads periodically
setInterval(() => {
  chrome.storage.local.get({ downloads: [] }, (result) => {
    if (result.downloads.length > 0) {
      console.log('📊 Download History:');
      result.downloads.forEach((d, i) => {
        console.log(`  ${i + 1}. ${d.platform} - ${d.filename} - ${d.status}`);
      });
    }
  });
}, 10000);

console.log('✅ Background script setup complete');
