// ============================================
// CONTENT.JS - Detect video conferencing platforms
// ============================================

console.log('✅ Content.js loaded!');

// Detect which platform we're on
function detectPlatform() {
  const url = window.location.href;
  
  if (url.includes('meet.google.com')) {
    return 'Google Meet';
  } else if (url.includes('zoom.us') || url.includes('zoom.com')) {
    return 'Zoom';
  } else if (url.includes('teams.microsoft.com')) {
    return 'Microsoft Teams';
  } else if (url.includes('discord.com')) {
    return 'Discord';
  } else if (url.includes('webex.com')) {
    return 'WebEx';
  }
  return 'Unknown Platform';
}

const platform = detectPlatform();
console.log('🎥 Platform detected:', platform);

// Wait for page to load
window.addEventListener('load', function() {
  console.log('📱 ' + platform + ' page loaded!');
  
  // Send message to background script
  chrome.runtime.sendMessage({
    action: 'PLATFORM_OPENED',
    platform: platform,
    url: window.location.href,
    timestamp: new Date().toISOString()
  }, (response) => {
    console.log('✅ Message sent to background:', response);
  });
  
  // Show notification on page
  showNotification(platform);
});

// Show notification function
function showNotification(platform) {
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #ff6b6b, #ff8e72);
    color: white;
    padding: 20px;
    border-radius: 8px;
    font-size: 14px;
    z-index: 999999;
    box-shadow: 0 5px 20px rgba(0,0,0,0.3);
    animation: slideIn 0.3s ease-out;
    font-weight: bold;
  `;
  notification.innerHTML = `
    🎥 ${platform} detected!<br>
    📥 File download initiated...
  `;
  document.body.appendChild(notification);
  
  setTimeout(() => notification.remove(), 5000);
}

console.log('✅ Content.js setup complete');
