// Load and display clickjacking data
function loadData() {
  chrome.storage.local.get({ clickjacks: [] }, (result) => {
    const clickjacks = result.clickjacks || [];
    
    console.log('📊 Loaded clickjacks:', clickjacks);
    
    // Update total clicks
    document.getElementById('totalClicks').textContent = clickjacks.length;
    
    // Count unique websites
    const websites = new Set(clickjacks.map(c => c.website));
    document.getElementById('websiteCount').textContent = websites.size;
    
    // Update list
    const list = document.getElementById('clickjackList');
    
    if (clickjacks.length === 0) {
      list.innerHTML = '<div class="empty-message">No attacks yet. Open a website and try clicking around!</div>';
      return;
    }
    
    // Show latest first
    const sortedClickjacks = [...clickjacks].reverse();
    
    list.innerHTML = sortedClickjacks.map((c, i) => `
      <div class="clickjack-item">
        <div>
          <span class="action-name">🎯 ${c.action}</span>
          <span class="website-name"> @ ${c.website}</span>
        </div>
        <div class="time-stamp">⏰ ${new Date(c.timestamp).toLocaleTimeString()}</div>
      </div>
    `).join('');
  });
}

// Refresh data
function refreshData() {
  console.log('🔄 Refreshing data...');
  loadData();
}

// Clear all data
function clearData() {
  if (confirm('Are you sure you want to clear all data?')) {
    chrome.storage.local.set({ clickjacks: [] }, () => {
      console.log('🗑️ Data cleared');
      loadData();
    });
  }
}

// Load data when popup opens
loadData();

// Auto-refresh every 1 second
setInterval(loadData, 1000);
