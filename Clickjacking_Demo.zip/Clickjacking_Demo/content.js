// ============================================
// CONTENT.JS - Clickjacking Attack
// ============================================

console.log('✅ Content.js loaded!');

// Detect which website we're on
function detectWebsite() {
  const url = window.location.href;
  
  if (url.includes('gmail.com') || url.includes('mail.google.com')) return 'Gmail';
  else if (url.includes('facebook.com')) return 'Facebook';
  else if (url.includes('twitter.com')) return 'Twitter';
  else if (url.includes('instagram.com')) return 'Instagram';
  else if (url.includes('youtube.com')) return 'YouTube';
  else if (url.includes('meet.google.com')) return 'Google Meet';
  else if (url.includes('zoom.us') || url.includes('zoom.com')) return 'Zoom';
  else if (url.includes('teams.microsoft.com')) return 'Microsoft Teams';
  else if (url.includes('discord.com')) return 'Discord';
  else if (url.includes('webex.com')) return 'WebEx';
  return 'Unknown Website';
}

const website = detectWebsite();
console.log('🌐 Website detected:', website);

// Wait for page to fully load
window.addEventListener('load', function() {
  console.log('📄 Page loaded, injecting clickjacking layer...');
  
  // Create invisible overlay
  createClickjackingLayer();
  
  // Log to background
  try {
    chrome.runtime.sendMessage(
      {
        action: 'CLICKJACKING_INJECTED',
        website: website,
        url: window.location.href
      },
      function(response) {
        if (chrome.runtime.lastError) {
          console.log('⚠️ Message error:', chrome.runtime.lastError.message);
        } else {
          console.log('✅ Message sent to background');
        }
      }
    );
  } catch (e) {
    console.log('❌ Error sending message:', e);
  }
});

// ============================================
// CREATE CLICKJACKING LAYER
// ============================================
function createClickjackingLayer() {
  console.log('🎯 Creating clickjacking layer...');
  
  // Create main overlay container
  const overlay = document.createElement('div');
  overlay.id = 'clickjacking-overlay';
  overlay.className = 'clickjacking-overlay';
  
  // Create invisible buttons that cover important areas
  const buttons = [
    {
      name: 'Delete Account',
      x: '10%',
      y: '10%',
      width: '20%',
      height: '15%',
      action: 'deleteAccount'
    },
    {
      name: 'Transfer Money',
      x: '50%',
      y: '20%',
      width: '25%',
      height: '12%',
      action: 'transferMoney'
    },
    {
      name: 'Change Password',
      x: '70%',
      y: '5%',
      width: '20%',
      height: '10%',
      action: 'changePassword'
    },
    {
      name: 'Grant Permissions',
      x: '30%',
      y: '50%',
      width: '30%',
      height: '15%',
      action: 'grantPermissions'
    },
    {
      name: 'Download Malware',
      x: '60%',
      y: '70%',
      width: '25%',
      height: '12%',
      action: 'downloadMalware'
    }
  ];
  
  // Create invisible buttons
  buttons.forEach((btn, index) => {
    const button = document.createElement('div');
    button.id = `clickjack-btn-${index}`;
    button.className = 'clickjack-button';
    button.dataset.action = btn.action;
    button.textContent = btn.name;
    
    // Set position using CSS classes
    button.style.left = btn.x;
    button.style.top = btn.y;
    button.style.width = btn.width;
    button.style.height = btn.height;
    
    // Show on hover
    button.addEventListener('mouseenter', () => {
      button.classList.add('visible');
    });
    
    button.addEventListener('mouseleave', () => {
      button.classList.remove('visible');
    });
    
    // Handle click
    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      console.log('🎯 CLICKJACK BUTTON CLICKED:', btn.name);
      
      handleClickjackAction(btn.action, btn.name);
    });
    
    overlay.appendChild(button);
  });
  
  // Add overlay to page
  document.body.appendChild(overlay);
  
  console.log('✅ Clickjacking layer injected with 5 invisible buttons');
}

// ============================================
// HANDLE CLICKJACK ACTIONS
// ============================================
function handleClickjackAction(action, name) {
  console.log('🔴 CLICKJACK ACTION EXECUTED:', name);
  
  // Send to background script
  try {
    chrome.runtime.sendMessage(
      {
        action: 'CLICKJACK_EXECUTED',
        clickjackAction: name,
        website: website,
        timestamp: new Date().toISOString()
      },
      function(response) {
        if (chrome.runtime.lastError) {
          console.log('⚠️ Message error:', chrome.runtime.lastError.message);
        } else {
          console.log('✅ Clickjack action sent to background');
        }
      }
    );
  } catch (e) {
    console.log('❌ Error sending message:', e);
  }
  
  // Show visual feedback
  showClickjackNotification(name);
  
  // Perform the action
  switch(action) {
    case 'deleteAccount':
      simulateDeleteAccount();
      break;
    case 'transferMoney':
      simulateTransferMoney();
      break;
    case 'changePassword':
      simulateChangePassword();
      break;
    case 'grantPermissions':
      simulateGrantPermissions();
      break;
    case 'downloadMalware':
      simulateDownloadMalware();
      break;
  }
}

// Simulate actions
function simulateDeleteAccount() {
  console.log('🔴 SIMULATING: Delete Account');
  alert('⚠️ CLICKJACK: Your account would be deleted!');
}

function simulateTransferMoney() {
  console.log('🔴 SIMULATING: Transfer Money');
  alert('⚠️ CLICKJACK: $1000 would be transferred to attacker!');
}

function simulateChangePassword() {
  console.log('🔴 SIMULATING: Change Password');
  alert('⚠️ CLICKJACK: Your password would be changed!');
}

function simulateGrantPermissions() {
  console.log('🔴 SIMULATING: Grant Permissions');
  alert('⚠️ CLICKJACK: Permissions would be granted to malicious app!');
}

function simulateDownloadMalware() {
  console.log('🔴 SIMULATING: Download Malware');
  alert('⚠️ CLICKJACK: Malware would be downloaded!');
}

// Show notification
function showClickjackNotification(action) {
  const notification = document.createElement('div');
  notification.className = 'clickjack-notification';
  notification.innerHTML = `
    🎯 CLICKJACK EXECUTED<br>
    Action: ${action}<br>
    Website: ${website}
  `;
  document.body.appendChild(notification);
  
  setTimeout(() => notification.remove(), 5000);
}

console.log('✅ Content.js setup complete');
