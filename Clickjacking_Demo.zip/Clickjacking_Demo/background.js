// ============================================
// BACKGROUND.JS - Track clickjacking attacks
// ============================================

console.log('✅ Background script loaded!');

let clickjackingHistory = [];

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Message received:', request.action);
  
  if (request.action === 'CLICKJACKING_INJECTED') {
    console.log('🎯 Clickjacking layer injected on:', request.website);
    console.log('📍 URL:', request.url);
    
    sendResponse({ success: true, message: 'Injection confirmed' });
  }
  
  if (request.action === 'CLICKJACK_EXECUTED') {
    console.log('🔴 CLICKJACK EXECUTED!');
    console.log('   Action:', request.clickjackAction);
    console.log('   Website:', request.website);
    console.log('   Time:', request.timestamp);
    
    // Get existing data
    chrome.storage.local.get({ clickjacks: [] }, (result) => {
      let clickjacks = result.clickjacks || [];
      
      console.log('📊 Current clickjacks in storage:', clickjacks.length);
      
      // Add new clickjack
      const newClickjack = {
        action: request.clickjackAction,
        website: request.website,
        timestamp: request.timestamp
      };
      
      clickjacks.push(newClickjack);
      
      console.log('➕ Added new clickjack. Total now:', clickjacks.length);
      
      // Keep only last 100
      if (clickjacks.length > 100) {
        clickjacks = clickjacks.slice(-100);
      }
      
      // Save to storage
      chrome.storage.local.set({ clickjacks: clickjacks }, () => {
        console.log('💾 Clickjack saved successfully');
        console.log('📊 Total clickjacks:', clickjacks.length);
      });
    });
    
    sendResponse({ success: true, message: 'Clickjack recorded' });
  }
  
  return true;
});

console.log('✅ Background script setup complete');
