
// ============================================
// JS load the text in search action
// ============================================
//document.write('Hello Null Bangalure Demo 1 - from Extension')

// ============================================
// JS MV2 paramter example
// ============================================
//eval('document.write("Hello Null Bangalure Demo 1 - from Extension - Eval")')

// ============================================
// JS MV2 paramter example
// ============================================
//
document["write"]("Hello Null Bangalure Demo 1 - from Extension")