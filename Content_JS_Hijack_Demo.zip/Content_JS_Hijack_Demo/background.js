// ============================================
// BACKGROUND.JS - Receives hijack data
// ============================================

console.log('✅ Background script loaded!');

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'PAGE_HIJACKED') {
    console.log('🔴 PAGE HIJACKED!');
    console.log('📍 URL:', request.url);
    console.log('🌐 Domain:', request.domain);
    console.log('📄 Title:', request.title);
    console.log('🔗 From tab:', sender.tab.id);
    
    // Store in local storage
    chrome.storage.local.get({ hijackedPages: [] }, (result) => {
      const pages = result.hijackedPages;
      pages.push({
        url: request.url,
        domain: request.domain,
        title: request.title,
        timestamp: new Date().toISOString(),
        tabId: sender.tab.id
      });
      
      // Keep only last 50
      if (pages.length > 50) pages.shift();
      
      chrome.storage.local.set({ hijackedPages: pages });
      console.log('💾 Stored. Total hijacked pages:', pages.length);
    });
    
    sendResponse({ success: true });
  }
});
