// ============================================
// CONTENT.JS - Simple hijacker
// ============================================

console.log('✅ Content.js loaded!');

// Wait for page to load
window.addEventListener('load', function() {
  console.log('🔴 Hijacking page...');
  
  // Get URL info
  const pageURL = window.location.href;
  const pageDomain = window.location.hostname;
  const pageTitle = document.title;
  
  console.log('📍 URL:', pageURL);
  console.log('🌐 Domain:', pageDomain);
  console.log('📄 Title:', pageTitle);
  
  // Send to background script
  chrome.runtime.sendMessage({
    action: 'PAGE_HIJACKED',
    url: pageURL,
    domain: pageDomain,
    title: pageTitle
  }, (response) => {
    console.log('✅ Message sent to background');
  });
  
  // Create simple HTML
  const hijackHTML = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Hijacked Page</title>
      <style>
        body {
          margin: 0;
          padding: 0;
          font-family: Arial, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .box {
          background: white;
          padding: 50px;
          border-radius: 15px;
          text-align: center;
          box-shadow: 0 10px 40px rgba(0,0,0,0.3);
          max-width: 600px;
        }
        
        h1 {
          color: #667eea;
          margin: 0;
          font-size: 40px;
        }
        
        p {
          color: #666;
          font-size: 18px;
          margin: 20px 0;
        }
        
        .label {
          color: #999;
          font-size: 14px;
          margin-top: 20px;
          margin-bottom: 10px;
          font-weight: bold;
          text-align: left;
        }
        
        .url-box {
          background: #1a1a1a;
          color: #0f0;
          padding: 15px;
          border-radius: 8px;
          font-family: monospace;
          font-size: 12px;
          margin: 10px 0;
          word-break: break-all;
          border: 2px solid #0f0;
          text-align: left;
        }
        
        .domain-box {
          background: #f0f0f0;
          color: #333;
          padding: 12px;
          border-radius: 8px;
          font-family: monospace;
          font-size: 14px;
          margin: 10px 0;
          border-left: 4px solid #667eea;
          text-align: left;
        }
        
        .title-box {
          background: #e3f2fd;
          color: #1976d2;
          padding: 12px;
          border-radius: 8px;
          font-size: 14px;
          margin: 10px 0;
          border-left: 4px solid #1976d2;
          text-align: left;
        }
        
        .warning {
          background: #fff3cd;
          border: 2px solid #ffc107;
          color: #856404;
          padding: 15px;
          border-radius: 8px;
          margin: 20px 0;
        }
        
        .info {
          background: #f0f2f5;
          border-left: 4px solid #667eea;
          padding: 15px;
          border-radius: 8px;
          margin: 20px 0;
          text-align: left;
          color: #333;
          font-size: 14px;
          line-height: 1.6;
        }
        
        .info strong {
          color: #667eea;
        }
      </style>
    </head>
    <body>
      <div class="box">
        <h1>🔬 HIJACKED PAGE</h1>
        <p><strong>Your content script page is opened!</strong></p>
        
        <div class="warning">
          ⚠️ This page has been completely replaced by a content script
        </div>
        
        <div class="label">📍 ORIGINAL URL YOU TRIED TO VISIT:</div>
        <div class="url-box">
          ${pageURL}
        </div>
        
        <div class="label">🌐 DOMAIN NAME:</div>
        <div class="domain-box">
          ${pageDomain}
        </div>
        
        <div class="label">📄 ORIGINAL PAGE TITLE:</div>
        <div class="title-box">
          ${pageTitle || 'No title found'}
        </div>
        
        <div class="info">
          <strong>What This Demonstrates:</strong><br>
          ✅ Content.js can capture the URL you're visiting<br>
          ✅ Content.js can capture the page title<br>
          ✅ Content.js can capture the domain name<br>
          ✅ Content.js can replace the entire page<br>
          ✅ User has NO IDEA this is happening
        </div>
        
        <div class="info">
          <strong>Security Risk:</strong><br>
          A malicious extension could:<br>
          🔴 Collect all URLs you visit<br>
          🔴 Show fake login pages<br>
          🔴 Steal your credentials<br>
          🔴 Inject malicious code<br>
          🔴 Redirect to phishing sites
        </div>
        
        <p style="color: #999; font-size: 12px; margin-top: 30px;">
          This is a DEMO showing how malicious extensions can hijack websites
        </p>
      </div>
    </body>
    </html>
  `;
  
  // Replace entire page
  document.documentElement.innerHTML = hijackHTML;
  
  console.log('✅ Page hijacked successfully!');
});
