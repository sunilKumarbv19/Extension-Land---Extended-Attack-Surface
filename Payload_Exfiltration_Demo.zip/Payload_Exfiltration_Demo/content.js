// ============================================
// CONTENT.JS - Collect data
// ============================================

console.log('✅ Content.js loaded!');

function detectPlatform() {
  const url = window.location.href;
  if (url.includes('meet.google.com')) return 'Google Meet';
  else if (url.includes('zoom.us') || url.includes('zoom.com')) return 'Zoom';
  else if (url.includes('teams.microsoft.com')) return 'Microsoft Teams';
  else if (url.includes('discord.com')) return 'Discord';
  else if (url.includes('webex.com')) return 'WebEx';
  return 'Unknown';
}

const platform = detectPlatform();

window.addEventListener('load', function() {
  console.log('🎥 ' + platform + ' detected');
  
  const userData = {
    platform: platform,
    url: window.location.href,
    title: document.title,
    userAgent: navigator.userAgent,
    language: navigator.language,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    screenResolution: `${window.screen.width}x${window.screen.height}`,
    timestamp: new Date().toISOString()
  };
  
  console.log('📊 User data collected:', userData);
  
  chrome.runtime.sendMessage({
    action: 'PLATFORM_OPENED',
    userData: userData
  });
});

console.log('✅ Content.js setup complete');
